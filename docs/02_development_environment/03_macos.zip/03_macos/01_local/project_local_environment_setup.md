# macOS 프로젝트 로컬 개발환경 구성

## 1. 개요

Apple Silicon 기반 macOS에서도 macOS 개발환경과 동일한 운영 개념을 사용한다.

Windows의 `~/local-microserver`에 대응하는 macOS 표준 Root는 다음과 같다.

```text
~/local-microserver
```

개발환경 Package를 이 Root에 풀고 초기화 Script와 Shortcut 생성 Script를 실행한 뒤,
전용 VS Code Launcher로 개발을 시작한다.

## 2. 권장 Directory 구조

```text
~/local-microserver
├─ tools
│  ├─ jdk
│  │  └─ temurin-25.jdk
│  │     └─ Contents
│  │        └─ Home
│  ├─ gradle
│  │  └─ gradle-<version>
│  └─ vscode
│     ├─ Visual Studio Code.app
│     └─ code-portable-data
├─ gradle-home
├─ workspace
│  ├─ microserver
│  └─ microserver-docs
└─ env
   ├─ setup.command
   ├─ create-vscode-shortcut.command
   ├─ start-vscode.command
   ├─ local-env.example.sh
   └─ local-env.sh
```

## 3. 하나의 Root로 관리하는 이유

- JDK / Gradle / VS Code Version을 프로젝트 기준으로 통제할 수 있다.
- 개발자의 일반 macOS 환경과 MicroServer 환경을 분리할 수 있다.
- 다른 Mac으로 이동할 때 동일 Directory 구조를 복원하기 쉽다.
- Portable VS Code Settings와 Extension을 함께 전달할 수 있다.
- `workspace`와 개발 Tool의 경계를 명확하게 유지할 수 있다.

## 4. JDK 배치 기준

JDK Installer로 시스템 전체에 고정하기보다 Apple Silicon용 압축 배포본을 `tools/jdk` 아래에 둔다.

```text
~/local-microserver/tools/jdk/temurin-25.jdk/Contents/Home
```

시스템 전역 `JAVA_HOME`을 MicroServer 때문에 영구 변경하지 않는다.
`start-vscode.command`가 VS Code를 시작할 때 Session 환경으로 주입한다.

## 5. Gradle 관리 기준

개발환경 준비 단계에서는 `tools/gradle`에 검증된 Binary Distribution을 둘 수 있다.

```text
~/local-microserver/tools/gradle/gradle-<version>
```

프로젝트 생성 이후 실제 Build는 Gradle Wrapper를 기준으로 한다.

```bash
./gradlew build
```

Gradle Cache는 사용자 Home의 `~/.gradle` 대신 다음 경로로 격리할 수 있다.

```text
~/local-microserver/gradle-home
```

## 6. Git Repository 구성

`~/local-microserver` 전체를 Git Repository로 만들지 않는다.

```text
~/local-microserver/workspace/
├─ microserver/.git
└─ microserver-docs/.git
```

Root는 개발환경 Container 역할이고 각 Source Directory가 독립 Repository이다.

## 7. Portable VS Code

macOS Portable Mode는 다음 구조를 사용한다.

```text
~/local-microserver/tools/vscode/
├─ Visual Studio Code.app
└─ code-portable-data/
```

`code-portable-data`에는 User Data와 Extension을 보관할 수 있다.

## 8. 초기 Setup Script

Package를 압축 해제한 뒤:

```bash
cd ~/local-microserver
chmod +x env/*.command
./env/setup.command
```

`setup.command`는 필요한 Directory와 개인 환경파일 Example을 준비한다.

## 9. Shortcut 생성

```bash
./env/create-vscode-shortcut.command
```

Desktop에 다음 실행 진입점을 만든다.

```text
~/Desktop/MicroServer VS Code.command
```

이 파일은 실제 `env/start-vscode.command`를 가리키도록 구성한다.

## 10. VS Code 실행 Script

`start-vscode.command`는 다음 환경을 현재 Process에 적용한다.

```text
JAVA_HOME
GRADLE_HOME
GRADLE_USER_HOME
PATH
```

그 후 `Visual Studio Code.app`과 `workspace`를 실행한다.

## 11. Local Secret

개인 Password나 Token은 다음 파일에서 관리한다.

```text
~/local-microserver/env/local-env.sh
```

이 파일은 공용 Package와 Git에서 제외한다.

## 12. macOS 실행 권한과 Gatekeeper

`.command` 파일은 실행 권한이 필요하다.

```bash
chmod +x ~/local-microserver/env/*.command
```

다운로드한 App 또는 Script가 macOS 보안정책의 영향을 받는 경우 조직 정책을 우선한다.
Portable VS Code가 동작하지 않을 때는 VS Code App의 quarantine 상태도 확인할 수 있다.

## 13. 최종 확인

```bash
uname -m
git --version
java -version
javac -version
gradle --version
```

Apple Silicon 장비에서는 일반적으로 다음이 표시된다.

```text
arm64
```

## 14. 구성 완료 기준

- [ ] `~/local-microserver`가 존재한다.
- [ ] JDK / Gradle / VS Code가 `tools` 아래에 있다.
- [ ] `code-portable-data`가 VS Code App과 같은 상위 Directory에 있다.
- [ ] `setup.command`가 정상 실행된다.
- [ ] Desktop Shortcut이 생성된다.
- [ ] Shortcut으로 VS Code가 실행된다.
- [ ] VS Code Terminal에서 Java/Gradle이 정상 인식된다.
